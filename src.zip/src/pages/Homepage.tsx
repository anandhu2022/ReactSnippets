import {useAuth} from "../context/AuthContext.tsx";

const Homepage = () => {
    const {login, logout, user} = useAuth();
    return (
        <>
            <button onClick={login}>Login</button>
            <button onClick={logout}>Login</button>
            {user && <h1>Welcome, {user.username}!</h1>}
        </>
    );
};

export default Homepage;
