import AuthProvider from "./context/AuthContext.tsx";
import Homepage from "./pages/Homepage.tsx";

const App = () => {
    return (
        <AuthProvider>
            <Homepage/>
        </AuthProvider>
    );
};

export default App;
